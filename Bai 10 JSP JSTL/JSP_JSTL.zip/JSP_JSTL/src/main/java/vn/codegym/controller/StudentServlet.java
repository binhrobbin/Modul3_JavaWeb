package vn.codegym.controller;

import vn.codegym.model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "studentServlet", urlPatterns = "/student")
public class StudentServlet extends HttpServlet {
    private static List<Student> studentList;

    static {
        studentList = new ArrayList<>();
        studentList.add(new Student(1, "Nguyen Van A", 1, 100,"avatar.png"));
        studentList.add(new Student(2, "Nguyen Van B", 0, 10,"avatar_1.jpg"));
        studentList.add(new Student(3, "Nguyen Van C", 2, 50,"avatar_2.png"));
        studentList.add(new Student(4, "Nguyen Van D", 1, 80,"avatar_3.jpg"));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.sendRedirect("/student/list.jsp");
        req.setAttribute("studentList", studentList);
        req.getRequestDispatcher("/student/list.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
