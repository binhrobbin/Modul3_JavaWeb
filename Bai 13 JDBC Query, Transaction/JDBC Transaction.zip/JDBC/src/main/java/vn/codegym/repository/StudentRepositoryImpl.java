package vn.codegym.repository;

import vn.codegym.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentRepositoryImpl implements IStudentRepository {

    private static final String SELECT_ALL_STUDENT = "select * from student";

    @Override
    public List<Student> finAll() {
        Connection connection = DBConnection.getConnection();
        PreparedStatement statement = null; //nạp lệnh SQL
        ResultSet resultSet = null; //nhận kq trả về từ DB
        List<Student> studentList = new ArrayList<>();

        if (connection != null) {
            try {
                statement = connection.prepareStatement(SELECT_ALL_STUDENT);
                resultSet = statement.executeQuery();

                Student student = null;
                while (resultSet.next()) {
                    int id = resultSet.getInt(1);
                    String name = resultSet.getString("name");
                    int gender = resultSet.getInt("gender");
                    int point = resultSet.getInt("point");
                    String image = resultSet.getString("image");

                    student = new Student(id, name, gender, point, image);
                    studentList.add(student);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                DBConnection.close();
            }
        }

        return studentList;
    }

    @Override
    public void save(Student student) {
        Connection connection = DBConnection.getConnection();
        PreparedStatement statement = null; //nạp lệnh SQL

        if (connection != null) {
            try {
                statement = connection.prepareStatement("insert into student(id, name, gender, point, image) " +
                        "value (?, ?, ?, ?, ?) ");
                statement.setInt(1, student.getId());
                statement.setString(2, student.getName());
                statement.setInt(3, student.getGender());
                statement.setInt(4, student.getPoint());
                statement.setString(5, student.getImage());
                statement.executeUpdate();

            } catch (SQLException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    statement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                DBConnection.close();
            }
        }
    }

    public static double avgPoint(){
        Connection connection = DBConnection.getConnection();
        CallableStatement statement = null;
        double avgPoint = 0.0;
        if(connection != null){
            try{
                statement = connection.prepareCall("call avg_point(?)");
                statement.executeQuery();
                avgPoint = statement.getDouble(1); //out

            } catch (SQLException e){
                e.printStackTrace();
            } finally {
                try {
                    statement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                DBConnection.close();
            }
        }

        return avgPoint;
    }

    public static String findByid(int id){
        Connection connection = DBConnection.getConnection();
        CallableStatement statement = null;
        String studentName = null;
        if(connection != null){
            try{
                statement = connection.prepareCall("call search_name_by_id(?, ?)");
                statement.setInt(1, id); //in

                statement.executeQuery();

                studentName = statement.getString(2); //out
            } catch (SQLException e){
                e.printStackTrace();
            } finally {
                try {
                    statement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                DBConnection.close();
            }
        }

        return studentName;
    }

    public static void save2() throws SQLException {
        Connection connection = DBConnection.getConnection();
        PreparedStatement statement = null; //nạp lệnh SQL
        Student student = new Student(5, "A", 1, 55,"");
        Student studen2 = new Student(4, "B", 1, 55,"");

        Savepoint savepoint = null;
        if (connection != null) {
            try {
                connection.setAutoCommit(false);
                statement = connection.prepareStatement("insert into student(id, name, gender, point, image) " +
                        "value (?, ?, ?, ?, ?) ");
                statement.setInt(1, student.getId());
                statement.setString(2, student.getName());
                statement.setInt(3, student.getGender());
                statement.setInt(4, student.getPoint());
                statement.setString(5, student.getImage());
                statement.executeUpdate();

                savepoint = connection.setSavepoint();

                statement = connection.prepareStatement("insert into student(id, name, gender, point, image) " +
                        "value (?, ?, ?, ?, ?) ");
                statement.setInt(1, studen2.getId());
                statement.setString(2, studen2.getName());
                statement.setInt(3, studen2.getGender());
                statement.setInt(4, studen2.getPoint());
                statement.setString(5, studen2.getImage());
                statement.executeUpdate();

                connection.commit();

            } catch (SQLException e) {
                e.printStackTrace();
                if(savepoint != null){
                    connection.rollback(savepoint);
                    connection.commit();
                }
            } finally {
                try {
                    statement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
                DBConnection.close();
            }
        }
    }

    public static void main(String[] args) throws SQLException {
       save2();
    }
}
